export const shortenTitle = (title) => {
    return title.split(' (')[0];
};